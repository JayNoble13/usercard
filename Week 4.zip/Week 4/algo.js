var newarray = [2, 4, 6, -2];
var count = 0;
var negcount = 0;

for (var i = 0; i<newarray.length; i++){
    if(newarray[i]>=0){
        count++
    }
    else if(newarray[i]<0);
}

console.log(count);
console.log(negcount);